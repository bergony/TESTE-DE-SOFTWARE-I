package lib.exceptions;

public class InsertEntryException extends Exception {

	public InsertEntryException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InsertEntryException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InsertEntryException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public InsertEntryException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InsertEntryException(Exception e) {
		super(e);
	}

}
