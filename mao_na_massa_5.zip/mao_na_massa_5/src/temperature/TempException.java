package temperature;

public class TempException extends Exception {

	public TempException(String string) {
		super(string);
	}

}
