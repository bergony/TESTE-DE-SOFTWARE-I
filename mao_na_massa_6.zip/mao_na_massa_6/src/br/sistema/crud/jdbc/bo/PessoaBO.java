package br.sistema.crud.jdbc.bo;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import br.sistema.crud.jdbc.dao.PessoaDAO;
import br.sistema.crud.jdbc.dto.EnderecoDTO;
import br.sistema.crud.jdbc.dto.PessoaDTO;
import br.sistema.crud.jdbc.exception.NegocioException;
import br.sistema.crud.jdbc.exception.ValidacaoException;

public class PessoaBO {

	private DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	
	public void cadastrar(PessoaDTO pessoaDTO, PessoaDAO pessoaDAO) throws NegocioException {
		try {
			pessoaDAO.inserir(pessoaDTO);
		} catch(Exception exception) {
			exception.printStackTrace();
			throw new NegocioException(exception.getMessage());
		}
	}
	
	public String[][] listagem(List<Integer> idsPessoas, PessoaDAO pessoaDAO) throws NegocioException {
		int numCols = 10;
		String[][] listaRetorno = null;
		try {
			
			List<PessoaDTO> lista = pessoaDAO.listarTodos();
			listaRetorno = new String[lista.size()][numCols];
			
			for (int i = 0; i < lista.size(); i++) {
				PessoaDTO pessoa = lista.get(i);
				EnderecoDTO enderecoDTO = pessoa.getEnderecoDTO();
				listaRetorno[i][0] = pessoa.getIdPessoa().toString();
				idsPessoas.add(pessoa.getIdPessoa());
				listaRetorno[i][1] = pessoa.getNome();
				listaRetorno[i][2] = pessoa.getCpf().toString();
				listaRetorno[i][3] = pessoa.getSexo() == 'M' ? "Masculino" : "Feminino";
				listaRetorno[i][4] = dateFormat.format(pessoa.getDtNascimento());
				listaRetorno[i][5] = enderecoDTO.getLogadouro();
				listaRetorno[i][6] = enderecoDTO.getUfDTO().getSiglaUF();
				listaRetorno[i][7] = enderecoDTO.getCep().toString();
				listaRetorno[i][8] = "ALTER";
				listaRetorno[i][9] = "DEL";
			}
		} catch(Exception exception) {
			throw new NegocioException(exception.getMessage());
		}
		return listaRetorno;
	}
	
	public boolean validaNome(String nome) throws ValidacaoException {
		boolean ehValido = true;
		if (nome == null || nome.equals("")) {
			ehValido = false;
			throw new ValidacaoException("Campo nome � obrigat�rio!");
		} else if (nome.length() > 30) {
			ehValido = false;
			throw new ValidacaoException("Campo nome comporta no m�ximo 30 chars!");
		}
		return ehValido;
	}
	
	public boolean validaCpf(String cpf) throws ValidacaoException {
		boolean ehValido = true;
		if (cpf == null || cpf.equals("")) {
			ehValido = false;
			throw new ValidacaoException("Campo CPF � obrigat�rio!");
		} else if (cpf.length() != 11) {
			ehValido = false;
			throw new ValidacaoException("Campo CPF deve ter 11 d�gitos!");
		} else {
			char[] digitos = cpf.toCharArray();
			for (char digito : digitos) {
				if (!Character.isDigit(digito)) {
					ehValido = false;
					throw new ValidacaoException("Campo CPF � somente num�rico!");
				}
			}
		}
		return ehValido;
	}
	
	public boolean validaEndereco(EnderecoDTO enderecoDTO) throws ValidacaoException {
		boolean ehValido = true;
		if (enderecoDTO.getLogadouro() == null || enderecoDTO.getLogadouro().equals("")) {
			ehValido = false;
			throw new ValidacaoException("Campo Logradouro � obrigat�rio!");
		} else if (enderecoDTO.getBairro() == null || enderecoDTO.getBairro().equals("")) {
			ehValido = false;
			throw new ValidacaoException("Bairro Obrigatorio");
		} else if (enderecoDTO.getNumero() == null || enderecoDTO.getNumero().equals(0)) {
			ehValido = false;
			throw new ValidacaoException("Numero Obrigatorio");
		}else if (enderecoDTO.getCep() == null || enderecoDTO.getCep().equals(0)) {
			ehValido = false;
			throw new ValidacaoException("CEP Obrigatorio");
		}
	

		return ehValido;
	}
	
	public boolean validaDtNasc(String dtNasc) throws ValidacaoException {
		boolean ehValido = true;
		if (dtNasc == null || dtNasc.equals("")) {
			ehValido = false;
			throw new ValidacaoException("Campo Dt. Nasc. � obrigat�rio!");
		} else {
			ehValido = false;
			try {
				dateFormat.parse(dtNasc);
			} catch (ParseException e) {
				throw new ValidacaoException("Formato inv�lido de data!");
			}
		}
		return ehValido;
	}
	
	public void removePessoa(Integer idPessoa, Integer idEndereco, PessoaDAO pessoaDAO) throws NegocioException {
		try {
			pessoaDAO.deletar(idPessoa);
		} catch(Exception exception) {
			throw new NegocioException(exception.getMessage());
		}
	}

	public void removeTudo(PessoaDAO pessoaDAO) throws NegocioException {
		try {
			pessoaDAO.deletarTudo();
			
		} catch(Exception e) {
			throw new NegocioException(e.getMessage());
		}
	}
	
	public PessoaDTO buscaPorId(Integer idPessoa, PessoaDAO pessoaDAO) throws NegocioException{
		PessoaDTO pessoaDTO = null;
		
		try {
			pessoaDTO = pessoaDAO.buscarPorId(idPessoa);
		} catch (Exception e) {
			throw new NegocioException(e.getMessage(), e);
			
		}
		return pessoaDTO;
	}
	
}
