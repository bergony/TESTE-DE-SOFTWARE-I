package lib.exceptions;

public class CommunicationException extends Exception implements java.io.Serializable {

    public CommunicationException(String s) {
        super(s);
    }
}


/*--- Formatted in Sun Java Convention Style on Mon, Oct 30, '00 ---*/


/*------ Formatted by Jindent 3.23 Gold 1.02 Trial --- http://www.jindent.de ------*/
